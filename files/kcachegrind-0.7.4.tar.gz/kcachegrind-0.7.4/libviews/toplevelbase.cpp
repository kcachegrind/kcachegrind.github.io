#include "toplevelbase.h"

TopLevelBase::~TopLevelBase()
{}
